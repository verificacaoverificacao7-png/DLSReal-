package com.dlsreal

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class EnhanceRenderer(private val onReady: (SurfaceTexture) -> Unit) :
    GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {

    @Volatile var strength = 1f
    @Volatile var texW = 1
    @Volatile var texH = 1
    @Volatile private var fresh = false
    private val t0 = System.nanoTime()
    private var tex = 0
    private var prog = 0
    private var st: SurfaceTexture? = null
    private val mtx = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val quad = ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f)); position(0)
    }

    private val vs = """
        attribute vec2 aPos; attribute vec2 aUV; uniform mat4 uMtx; varying vec2 vUV;
        void main(){ gl_Position = vec4(aPos,0.0,1.0); vUV = (uMtx*vec4(aUV,0.0,1.0)).xy; }
    """.trimIndent()

    // Efeito: bloom + relevo/luz falsa + oclusao ambiente falsa + nitidez + tone mapping + vignette
    private val fs = """
        #extension GL_OES_EGL_image_external : require
        precision highp float;
        varying vec2 vUV; uniform samplerExternalOES uTex; uniform vec2 uTexel; uniform float uStrength; uniform float uTime;
        vec3 S(vec2 uv){ return texture2D(uTex, uv).rgb; }
        float L(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }
        void main(){
          vec3 o = S(vUV); vec3 c = o;
          vec3 bloom = vec3(0.0); vec3 blur = vec3(0.0); float avg = 0.0;
          for (int i=0;i<12;i++){
            float a = float(i)*0.5236; vec2 d = vec2(cos(a),sin(a));
            bloom += max(S(vUV+d*uTexel*6.0)-0.55,0.0) + 0.8*max(S(vUV+d*uTexel*14.0)-0.55,0.0);
          }
          bloom /= 12.0;
          for (int i=0;i<8;i++){
            float a = float(i)*0.7854; vec2 d = vec2(cos(a),sin(a));
            blur += S(vUV+d*uTexel*3.0); avg += L(S(vUV+d*uTexel*6.0));
          }
          blur /= 8.0; avg /= 8.0;
          c += (c-blur)*0.9;                                  // nitidez / detalhe
          c *= 1.0 - clamp(avg-L(o),0.0,1.0)*1.6;             // oclusao ambiente falsa
          float gx = L(S(vUV+vec2(uTexel.x,0.0)))-L(S(vUV-vec2(uTexel.x,0.0)));
          float gy = L(S(vUV+vec2(0.0,uTexel.y)))-L(S(vUV-vec2(0.0,uTexel.y)));
          vec3 n = normalize(vec3(-gx*4.0,-gy*4.0,1.0));      // normal falsa pelo gradiente
          vec3 Ld = normalize(vec3(cos(uTime*0.35)*0.7, sin(uTime*0.35)*0.5+0.3, 0.7)); c *= 0.78 + 0.5*max(dot(n,Ld),0.0);
          c += bloom*(1.1+0.2*sin(uTime*1.7))*vec3(1.0,0.95,0.85);                 // brilho quente
          c = mix(c*vec3(0.95,0.98,1.05), c*vec3(1.05,1.0,0.93), smoothstep(0.2,0.8,L(c))); // grading
          float ae = 0.0; for (int i=0;i<9;i++){ ae += L(S(vec2(0.17+0.33*float(i-(i/3)*3), 0.17+0.33*float(i/3)))); } ae /= 9.0;
          c *= clamp(0.45/max(ae,0.05),0.85,1.3);
          c = (c*(2.51*c+0.03))/(c*(2.43*c+0.59)+0.14);       // tone map filmico
          float g = L(c); c = mix(vec3(g), c, 1.18);          // saturacao
          vec2 q = vUV-0.5; c *= 1.0 - dot(q,q)*0.7;          // vignette
          gl_FragColor = vec4(mix(o, clamp(c,0.0,1.0), uStrength), 1.0);
        }
    """.trimIndent()

    override fun onFrameAvailable(s: SurfaceTexture?) { fresh = true }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        st?.release()
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        for ((k, v) in listOf(GLES20.GL_TEXTURE_MIN_FILTER to GLES20.GL_LINEAR, GLES20.GL_TEXTURE_MAG_FILTER to GLES20.GL_LINEAR,
            GLES20.GL_TEXTURE_WRAP_S to GLES20.GL_CLAMP_TO_EDGE, GLES20.GL_TEXTURE_WRAP_T to GLES20.GL_CLAMP_TO_EDGE))
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, k, v)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(prog, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(prog)
        st = SurfaceTexture(tex).also { it.setOnFrameAvailableListener(this); onReady(it) }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) = GLES20.glViewport(0, 0, w, h)

    override fun onDrawFrame(gl: GL10?) {
        if (fresh) { fresh = false; st?.updateTexImage(); st?.getTransformMatrix(mtx) }
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos"); val aUV = GLES20.glGetAttribLocation(prog, "aUV")
        quad.position(0); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2); GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMtx"), 1, false, mtx, 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uTexel"), 1f / texW, 1f / texH)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uStrength"), strength)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uTime"), (System.nanoTime() - t0) / 1e9f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type); GLES20.glShaderSource(s, src); GLES20.glCompileShader(s); return s
    }
}
