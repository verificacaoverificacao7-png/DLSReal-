package com.dlsreal

import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var renderer: EnhanceRenderer
    private lateinit var tab: LinearLayout
    private lateinit var tabLp: WindowManager.LayoutParams
    private lateinit var onBtn: TextView
    private var fxWin: FrameLayout? = null
    private var glView: GLSurfaceView? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var surface: Surface? = null
    private var capW = 1
    private var capH = 1
    private var on = false
    private var started = false
    private var level = 1
    private val strengths = floatArrayOf(0.5f, 1f)
    private val names = arrayOf("FX1", "FX2")
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY
        started = true
        startFg()
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent!!.getIntExtra("code", 0), data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        buildTab()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("dls", "DLS Real", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "dls").setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("DLS Real ativo").addAction(0, "Parar", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(m); return m.widthPixels to m.heightPixels
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, color: Int) = TextView(this).apply {
        text = t; setTextColor(color); textSize = 15f; gravity = Gravity.CENTER
        setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    // Abinha preta pequena: OFF/ON, FX, X
    private fun buildTab() {
        renderer = EnhanceRenderer { t -> main.post { attachSurface(t) } }
        renderer.strength = strengths[level]
        tabLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(8) }
        tab = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(0xE6000000.toInt()); cornerRadius = dp(14).toFloat() }
        }
        val grip = label("⋮⋮", Color.GRAY)
        onBtn = label("OFF", Color.RED).apply { setOnClickListener { toggle() } }
        val fx = label(names[level], Color.WHITE)
        fx.setOnClickListener { level = (level + 1) % 2; renderer.strength = strengths[level]; fx.text = names[level] }
        val close = label("✕", Color.WHITE).apply { setOnClickListener { stopSelf() } }
        listOf(grip, onBtn, fx, close).forEach { tab.addView(it) }
        layoutCapture()
        drag(grip)
        wm.addView(tab, tabLp)
    }

    private fun toggle() {
        if (on) turnOff() else turnOn()
        onBtn.text = if (on) "ON" else "OFF"
        onBtn.setTextColor(if (on) 0xFF00E676.toInt() else Color.RED)
    }

    // Camada em tela cheia que NAO bloqueia o toque: o jogo continua jogavel por baixo
    private fun turnOn() {
        if (Build.VERSION.SDK_INT < 34)
            Toast.makeText(this, "Android 14+ recomendado: no seu pode dar efeito espelho", Toast.LENGTH_LONG).show()
        val (w, h) = screen()
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2); setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        fxWin = FrameLayout(this).apply { addView(glView, FrameLayout.LayoutParams(-1, -1)) }
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; x = 0; y = 0
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        on = true
        wm.addView(fxWin, lp)
        wm.removeView(tab); wm.addView(tab, tabLp)   // abinha sempre por cima
    }

    private fun turnOff() {
        on = false
        display?.surface = null
        surface?.release(); surface = null
        runCatching { wm.removeView(fxWin) }
        fxWin = null; glView = null
    }

    // captura a 60% da resolucao (equilibrio entre nitidez e FPS do jogo)
    private fun layoutCapture() {
        val (w, h) = screen(); capW = w * 6 / 10; capH = h * 6 / 10
        renderer.texW = capW; renderer.texH = capH
        display?.resize(capW, capH, resources.displayMetrics.densityDpi)
    }

    private fun attachSurface(t: SurfaceTexture) {
        if (!on) return
        t.setDefaultBufferSize(capW, capH)
        val old = surface; surface = Surface(t)
        val d = display
        if (d == null) display = projection?.createVirtualDisplay("dlsreal", capW, capH,
            resources.displayMetrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
        else d.surface = surface
        old?.release()
    }

    private fun drag(v: View) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = tabLp.x; oy = tabLp.y }
                MotionEvent.ACTION_MOVE -> {
                    tabLp.x = ox + (e.rawX - sx).toInt(); tabLp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(tab, tabLp)
                }
            }; true
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (!started) return
        layoutCapture()
        if (on) { turnOff(); turnOn() }
    }

    override fun onDestroy() {
        if (started) { runCatching { turnOff() }; runCatching { wm.removeView(tab) } }
        display?.release(); projection?.stop()
        super.onDestroy()
    }
}
