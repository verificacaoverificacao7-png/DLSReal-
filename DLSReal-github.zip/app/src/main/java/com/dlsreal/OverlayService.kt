package com.dlsreal

import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var renderer: EnhanceRenderer
    private lateinit var glView: GLSurfaceView
    private lateinit var panel: FrameLayout
    private lateinit var bubble: TextView
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var surface: Surface? = null
    private var st: SurfaceTexture? = null
    private var capW = 1
    private var capH = 1
    private var preset = 2
    private var started = false
    private val main = Handler(Looper.getMainLooper())
    private val levels = floatArrayOf(0f, 0.6f, 1f)
    private val names = arrayOf("OFF", "FX1", "FX2")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY
        started = true
        startFg()
        val data = readData(intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent!!.getIntExtra("code", 0), data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        buildUi()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("dls", "DLS Real", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "dls").setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("DLS Real ativo").addAction(0, "Parar", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun screen(): Pair<Int, Int> {
        val m = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(m); return m.widthPixels to m.heightPixels
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayLp(w: Int, h: Int, secure: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (secure) WindowManager.LayoutParams.FLAG_SECURE else 0),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(8) }

    private fun chip(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
    }

    private fun buildUi() {
        renderer = EnhanceRenderer { t -> main.post { attachSurface(t) } }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2); setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        // FLAG_SECURE: a propria janela fica fora da captura (evita o efeito espelho infinito)
        panelLp = overlayLp(10, 10, true)
        bubbleLp = overlayLp(dp(48), dp(48), false)
        panel = FrameLayout(this)
        panel.addView(glView, FrameLayout.LayoutParams(-1, -1))

        val fx = chip(names[preset]).apply { setOnClickListener { cycle(this) } }
        val close = chip("✕").apply { setOnClickListener { hidePanel() } }
        val handle = chip("⤡")
        panel.addView(fx, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.START))
        panel.addView(close, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.END))
        panel.addView(handle, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.END))

        bubble = chip("□").apply { textSize = 22f; visibility = View.GONE }

        layoutCapture()
        resizePanel(screen().first * 4 / 10)
        drag(glView, panelLp, panel, null)
        drag(bubble, bubbleLp, bubble) { showPanel() }
        var startW = 0; var sx = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startW = panelLp.width; sx = e.rawX }
                MotionEvent.ACTION_MOVE -> { val w = screen().first
                    resizePanel((startW + (e.rawX - sx)).toInt().coerceIn(w / 5, w * 95 / 100)) }
            }; true
        }
        wm.addView(panel, panelLp)
        wm.addView(bubble, bubbleLp)
    }

    private fun cycle(v: TextView) {
        preset = (preset + 1) % levels.size
        renderer.strength = levels[preset]; v.text = names[preset]
    }

    private fun hidePanel() {
        bubbleLp.x = panelLp.x; bubbleLp.y = panelLp.y
        panel.visibility = View.GONE; glView.onPause()
        bubble.visibility = View.VISIBLE; wm.updateViewLayout(bubble, bubbleLp)
    }

    private fun showPanel() {
        panelLp.x = bubbleLp.x; panelLp.y = bubbleLp.y
        bubble.visibility = View.GONE
        panel.visibility = View.VISIBLE; glView.onResume(); wm.updateViewLayout(panel, panelLp)
    }

    // captura em metade da resolucao da tela (mais leve para a GPU)
    private fun layoutCapture() {
        val (w, h) = screen(); capW = w / 2; capH = h / 2
        renderer.texW = capW; renderer.texH = capH
        st?.setDefaultBufferSize(capW, capH)
        display?.resize(capW, capH, resources.displayMetrics.densityDpi)
    }

    // painel sempre com a mesma proporcao da tela
    private fun resizePanel(pw: Int) {
        val (w, h) = screen()
        panelLp.width = pw; panelLp.height = pw * h / w
        if (panel.isAttachedToWindow) wm.updateViewLayout(panel, panelLp)
    }

    private fun attachSurface(t: SurfaceTexture) {
        st = t; t.setDefaultBufferSize(capW, capH)
        val old = surface; surface = Surface(t)
        val d = display
        if (d == null) display = projection?.createVirtualDisplay("dlsreal", capW, capH,
            resources.displayMetrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
        else d.surface = surface
        old?.release()
    }

    private fun drag(v: View, lp: WindowManager.LayoutParams, target: View, onTap: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(target, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }; true
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (!started) return
        layoutCapture(); resizePanel(panelLp.width)
    }

    override fun onDestroy() {
        runCatching { wm.removeView(panel) }; runCatching { wm.removeView(bubble) }
        display?.release(); surface?.release(); projection?.stop()
        super.onDestroy()
    }
}
